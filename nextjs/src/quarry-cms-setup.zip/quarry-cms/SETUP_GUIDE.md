# The Quarry — CMS Setup Guide
## Sanity Studio + Next.js + Netlify

---

## WHAT YOU'RE SETTING UP

```
sanity.io/manage          → Your content admin panel (staff uses this)
        ↓ publishes content
GitHub (quarrymanagement) → Stores your site code
        ↓ auto-triggers
Netlify (The Quarry)      → Builds & hosts your live website
        ↓ serves
thequarrystl.com          → Your live site, always up to date
```

Every time a staff member hits "Publish" in Sanity, your site
automatically rebuilds and goes live in about 60 seconds.

---

## STEP 1 — UPLOAD CODE TO GITHUB

1. Go to github.com and sign in as quarrymanagement
2. Click the "+" icon → "New repository"
3. Name it: quarry-website
4. Set to Private
5. Click "Create repository"
6. On the next screen, click "uploading an existing file"
7. Drag and drop ALL the files from this zip (keep folder structure)
8. Commit message: "Initial site setup"
9. Click "Commit changes"

---

## STEP 2 — CONNECT NETLIFY TO GITHUB

1. Go to netlify.com → sign in
2. Click "Add new site" → "Import an existing project"
3. Choose "GitHub"
4. Authorize and find "quarry-website" repo
5. Settings:
   - Base directory: nextjs
   - Build command: npm run build
   - Publish directory: .next
6. Click "Deploy site"
7. While it deploys, go to Site Settings → Environment Variables
8. Add these:
   - Key: NEXT_PUBLIC_SANITY_PROJECT_ID
   - Value: 4t94f56h
9. Save and trigger a redeploy

---

## STEP 3 — SET UP SANITY STUDIO

1. Go to sanity.io/manage
2. Click your "The Quarry" project
3. Go to "API" → "CORS Origins"
4. Add your Netlify URL (e.g. https://thequarry.netlify.app)
5. Also add http://localhost:3000 for local development

### Deploy the Studio (your admin panel):
Open your computer's terminal and run:

```bash
# Install Sanity CLI
npm install -g @sanity/cli

# Go into sanity folder
cd sanity

# Install dependencies
npm install

# Log in to Sanity
sanity login

# Deploy the studio
sanity deploy
```

When asked for a studio hostname, enter: thequarry-admin
Your admin panel will be live at: https://thequarry-admin.sanity.studio

---

## STEP 4 — SET UP AUTO-REBUILD WEBHOOK

This is what makes saving in Sanity automatically update your live site.

1. In Netlify → Site Settings → Build & Deploy → Build hooks
2. Click "Add build hook"
3. Name it: "Sanity Content Update"
4. Copy the URL it gives you (looks like https://api.netlify.com/build_hooks/abc123)

5. Go to sanity.io/manage → The Quarry → API → Webhooks
6. Click "Create webhook"
7. Name: "Trigger Netlify Rebuild"
8. URL: paste the Netlify build hook URL
9. Trigger on: "Create", "Update", "Delete"
10. Filter (optional): leave blank to trigger on any change
11. Save

NOW: Every time you publish in Sanity → Netlify rebuilds → site updates in ~60 seconds.

---

## STEP 5 — ADD YOUR CONTENT TO SANITY

Go to https://thequarry-admin.sanity.studio and start adding:

### Site Settings (do this first)
- Phone, email, address
- Hours for each day
- Social media URLs
- Golf bay price, balls included, jackpot amount

### Menu Sections
Add each section in order:
1. Shareables (order: 1)
2. Sandwiches, Wraps & Sliders (order: 2)
3. Nachos (order: 3)
4. Soups & Salads (order: 4)
5. Kids Menu (order: 5)
6. Heaven / Desserts (order: 6)

For each section, add all items with name, description, price.

### Drink Menu
Same process — add sections (Wine, Cocktails, Beer, etc.)
with all items under each.

### Events
Add each upcoming event — fill in:
- Name, Date, Time, Location
- Event Type (Ticketed / Public / Fundraiser / Member)
- Price, Capacity, Registered count
- Description
- Registration URL (or leave blank for email inquiry)

### Band Schedule
Add each upcoming performance with name, date, time.

### Press Articles
Add each press article with outlet, headline, date, URL.
Mark VoyageSTL as "Featured".

### Job Postings
Add each open position with title, department, description.

---

## STAFF LOGIN CREDENTIALS

Share this URL with your team:
https://thequarry-admin.sanity.studio

They log in with their Google or GitHub account.
To give someone access:
1. sanity.io/manage → The Quarry → Members
2. Invite by email
3. Set role: Editor (can edit content but not settings)

---

## HOW STAFF UPDATES THE SITE

### To add a new event:
1. Go to thequarry-admin.sanity.studio
2. Click "Events" in left sidebar
3. Click "+ New Event"
4. Fill in the form
5. Click "Publish"
6. Site updates in 60 seconds ✓

### To update a menu price:
1. Click "Food Menu" in sidebar
2. Click the section (e.g. "Shareables")
3. Find the item, click the price, change it
4. Click "Publish"
5. Site updates in 60 seconds ✓

### To add a band:
1. Click "Band Schedule"
2. Click "+ New Band / Performance"
3. Enter name, date, time
4. Publish ✓

### To hide an event (sold out or cancelled):
1. Open the event
2. Toggle "Show on Website" to OFF
3. Publish ✓
OR toggle "Sold Out" to ON to show it as sold out.

---

## YOUR URLS AT A GLANCE

| URL | What it is |
|-----|-----------|
| thequarrystl.com | Your live website |
| thequarry-admin.sanity.studio | Staff admin panel |
| netlify.com | Hosting dashboard |
| github.com/quarrymanagement | Code repository |
| sanity.io/manage | Sanity project settings |

---

## NEED HELP?

Contact: management@thequarrystl.com
Developer setup questions: refer to this guide first,
then check sanity.io/docs and nextjs.org/docs

---

Built for The Quarry · New Melle, Missouri · 2026
